git tag -a "`date +'%Y%m%d'`" -m "Release `date +'%Y%m%d'`"
git push origin --tags