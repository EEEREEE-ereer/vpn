if __name__ == '__main__':
    print('This is a python repository')
