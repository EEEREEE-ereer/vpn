自定义solr filter
==========
[http://solr.pl/en/2012/05/14/developing-your-own-solr-filter/](http://solr.pl/en/2012/05/14/developing-your-own-solr-filter/)
