more like this
==============
参考[hMoreLikeThis](ttp://wiki.apache.org/solr/MoreLikeThis)
