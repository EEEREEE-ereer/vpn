SolrCloud：Transaction Logs、Soft Commit 和 Commit
==================================================
[参考](http://lucidworks.com/blog/understanding-transaction-logs-softcommit-and-commit-in-sorlcloud/)
