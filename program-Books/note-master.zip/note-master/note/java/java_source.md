Singleton Design Pattern – An Introspection w/ Best Practices[http://java.dzone.com/articles/singleton-design-pattern-%E2%80%93]
http://javarevisited.blogspot.com/2011/03/10-interview-questions-on-singleton.html
