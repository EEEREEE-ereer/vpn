Spring MVC
=============
Spring MVC 前端控制器是DispatcherServlet .应用控制器拆分为处理映射器(Handler Mapping)进行处理器管理和 视图解析器(View Resolver)进行视图管理.    


