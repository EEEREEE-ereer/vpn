http://www.codeinstructions.com/2009/01/busting-javalangstringintern-myths.html
