开发者必备的Chrome插件
====================
####Proxy SwitchyOmega
Proxy SwitchyOmega 是科学上网的必备神器，配合shadowsocks使用，功能非常强大，可以根据正则表达式决定哪些网址采用科学上网。  
  
![switchy](http://7i7hhc.com1.z0.glb.clouddn.com/proxy.webp)  

####Vimum
如果你是Vim爱好者，那么Vimum不应该错过，用更加Hacker的方式操作网页，完全可以用键盘替代电脑的触摸板。

![vimum](http://7i7hhc.com1.z0.glb.clouddn.com/VImum.jpg)

####Momentum
每天看到Chrome默认的空白页是不是有点太单调了，Momentum 给你焕然一新的感觉，它提供了漂亮的壁纸，每天换一图，还提供了简单的TODO List，天气等功能，这些功能都可以自定义。  
![momentum](http://7i7hhc.com1.z0.glb.clouddn.com/Momentum.webp)

####PostMan
PostMan Rest Client 一款功能强大的API开发调试的工具。
![postman](http://7i7hhc.com1.z0.glb.clouddn.com/postman.webp)

####Stylebot
Stylebot 可以把任何网站的页面的修改成你想要的界面，简单的用法就是去除页面的一些广告之类的。图是hacknews通过Stylebot美化之后的效果。  
![hacknews](http://7i7hhc.com1.z0.glb.clouddn.com/hacknews.jpg)


