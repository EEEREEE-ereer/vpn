#Bootstrap3入门指南---30分钟设计一个响应式布局页面
本教程教你如何使用Bootstrap3创建一个响应式布局页面，该页面主要包括一个相应式的banner和一个导航菜单，另外包括两列的内容布局和一个三列的footer。最后我们还会扩展BootStrap3的CSS，最终效果看起来应该是这样。  
![demo](http://www.revillweb.com/revillweb-theme/images/post-images/bootstrap-tutorial-1.png)

####准备工作
在动手之前，我们先要准备好一些材料，主要有如下步骤：  
1. 下载Twitter Bootstrap 和 jQuery库
