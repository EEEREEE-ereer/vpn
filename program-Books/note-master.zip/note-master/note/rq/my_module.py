#! /usr/bin/env python
# -*- coding: utf-8 -*-

import  time

def send_mail(email):
    # 假设模拟发送邮件需要一秒钟
    time.sleep(1)
    return 'ok'
