try_files.md

	Syntax:	try_files file ... uri;
	try_files file ... =code;
	Default:	—
	Context:	server, location

http://nginx.org/en/docs/http/ngx_http_core_module.html#try_files