try_file.md



http://nginx.org/en/docs/http/ngx_http_core_module.html#try_files

http://www.hi-linux.com/2016/03/29/Nginx%E7%9A%84try_files%E6%8C%87%E4%BB%A4%E4%BD%BF%E7%94%A8%E5%AE%9E%E4%BE%8B/

http://huoding.com/2013/10/23/290