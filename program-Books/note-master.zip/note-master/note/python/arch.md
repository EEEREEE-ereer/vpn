####数据持久层
数据库: MySQL, 缓存:Memecache  

####应用层
使用Mako作为模板语言, Web框架:Pyramid, ORM:SQLAlchemy,WSGI服务器是Gunicorn.Nginx作为代理.项目部署使用Fabric.搜索服务:Sphinx.静态文件托管在又拍云 ,邮件服务使用的是MailGun.   

####前端
jQuery  



