新工作知识点汇总
================
**tornado**  
tornado官方站点[英文](http://www.tornadoweb.org/en/stable/)[中文](http://www.tornadoweb.cn/)  
文档[英文](http://www.tornadoweb.org/en/stable/documentation.html)[中文](http://www.tornadoweb.cn/documentation)  

**mock**  
[the mock class](http://www.voidspace.org.uk/python/mock/mock.html)  
[get start with mock](http://www.voidspace.org.uk/python/mock/getting-started.html)  
[Replacing Redis with a Python Mock](http://seeknuance.com/2012/02/18/replacing-redis-with-a-python-mock/)  

**mongodb**  
[官方站点](https://www.mongodb.org/)  
[try](http://try.mongodb.org/)  
[文档](http://docs.mongodb.org/manual/)  
[50 Tips and Tricks for MongoDB  Developers.pdf](http://ishare.iask.sina.com.cn/f/18439195.html)  
[MongoDB权威指南](http://book.douban.com/subject/6068947/)  

**Redis**   
[官方站点](http://redis.io/)  
[中文站点](http://redis.cn/)  
[Redis设计与实现](http://redisbook.readthedocs.org/en/latest/)
[springside总结的Redis](https://github.com/springside/springside4/wiki/redis)  

**视频转码**  
[ffmpeg](http://www.ckplayer.com/manual.php?id=16)  
[ffmpeg官网](http://www.ffmpeg.org/index.html)  


