在不影响应用程序的同时，给用户一个提示

Toast.makeText(context, text, duration)
toast.setDuration(duration)
toast.setGravity(gravity, x, y)
toast.setText(s)
toast.show()

####Notification
**构建notification**：  

