Android应用程序中的主要组件：  

Activity：一个窗口或者一个对话框表示一个Activity。


findViewById()方法要在setContentView()之后调用，否者是找不到view的。  
