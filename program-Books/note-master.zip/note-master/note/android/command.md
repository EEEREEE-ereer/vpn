Android常用命令
==================

    adb devices             #列出所有设备  
    adb [ -s 设备id] shell  #远程登录到设备 
    

